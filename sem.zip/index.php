<?php

	header("location:beranda");

?>
