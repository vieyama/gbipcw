
            <!-- Footer -->
            <footer id="page-footer" class="opacity-0">
                <div class="content py-20 font-size-xs clearfix">
                    <div class="float-right">
                        Crafted with <i class="fa fa-heart text-pulse"></i> by <a class="font-w600" href="http://goo.gl/vNS3I" target="_blank">pixelcave</a>
                    </div>
                    <div class="float-left">
                        <a class="font-w600" href="https://goo.gl/po9Usv" target="_blank">Codebase 1.3</a> &copy; <span class="js-year-copy">2017</span>
                    </div>
                </div>
            </footer>
            <!-- END Footer -->
        </div>
        <!-- END Page Container -->

        <!-- Codebase Core JS -->
        <script src="admin/assets/js/core/jquery.min.js"></script>
        <script src="admin/assets/js/core/popper.min.js"></script>
        <script src="admin/assets/js/core/bootstrap.min.js"></script>
        <script src="admin/assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="admin/assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="admin/assets/js/core/jquery.appear.min.js"></script>
        <script src="admin/assets/js/core/jquery.countTo.min.js"></script>
        <script src="admin/assets/js/core/js.cookie.min.js"></script>
        <script src="admin/assets/js/codebase.js"></script>
        <!-- Page JS Plugins -->
        <script src="admin/assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="admin/assets/js/plugins/datatables/dataTables.bootstrap4.min.js"></script>

        <!-- Page JS Code -->
        <script src="admin/assets/js/pages/be_tables_datatables.js"></script>


        <!-- Page JS Plugins -->
        <script src="admin/assets/js/plugins/chartjs/Chart.bundle.min.js"></script>

        <!-- Page JS Code -->
        <script src="admin/assets/js/pages/be_pages_dashboard.js"></script>

        <!-- Page JS Plugins -->
      <script src="admin/assets/js/plugins/ckeditor/ckeditor.js"></script>
      <script src="admin/assets/js/plugins/simplemde/js/simplemde.min.js"></script>

      <!-- Page JS Code -->
      <script>
          jQuery(function () {
              // Init page helpers (CKEditor + SimpleMDE plugins)
              Codebase.helpers(['ckeditor', 'simplemde']);
          });
      </script>

    </body>
</html>
